var express = require('express');
var app = express();
var bodyParser = require("body-parser");

app.use(express.static(__dirname + "/public"));

const mySecret = process.env['MESSAGE_STYLE']

console.log("Hello World");

/*
app.get("/", function(req, res) {
  res.send("Hello Express");
});
*/

/*
app.get("/", function(req, res) {
  res.sendFile(__dirname + "/public/index.html");
});
*/

/*
var response = "Hello World";

if (process.env.MESSAGE_STYLE === "uppercase") {
  response = response.toUpperCase();
}

app.get("/json", (req, res) => {
  res.json({    
    message: response
  });
});
*/

app.get("/:word/echo", (req, res) => {
  const { word } = req.params;
  res.json({
    echo: word
  });
});












module.exports = app;
